# R_desnum
R package containing useful functions
